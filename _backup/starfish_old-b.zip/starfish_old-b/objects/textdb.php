<?php
if (!class_exists('starfish')) { die(); }

/**
 * Starfish text database
 *
 * @package starfish
 * @subpackage starfish.objects.textdb
 */
class textdb
{	
        /**
	 * Declare used variables
	 * 
	 * $connected - boolean - whether a connection has been established or not
	 * 
	 * $resource - the result of a select perfomed on a file
	 * $resource_fetch - the result up to which the fetching has been performed so far
	 * $resource_count - the number of results counted in the select
	 * 
	 * $path - to the database directory
	 * $info - info about the executed query
	 */
        private $connected = false;
        
        private $resource;
        private $resource_fetch = 0;
        private $resource_count = 0;
        
        private $path;
        private $info;

        /**
	 * Constructor
	 */
        function __construct()
        {
                // Establish the path to the database containing folder
                if (strlen(starfish::config('_starfish', 'storage')) > 0)
                {
                        $this->path = starfish::config('_starfish', 'storage') . 'textdb';
                }
                else
                {
                        $this->path = starfish::config('_starfish', 'storage') . 'textdb';
                }

                // Create the file if it does not exist
                if (!file_exists($this->path)) { starfish::obj('files')->smkdir($this->path); }
                
                return true;
        }
        
        /**
         * Function to connect to the database
         * 
         * @param string $database Name of the database to use. 
         */
        function connect($database)      
        {
                // Set the path inside this object
                $this->path .= DIRECTORY_SEPARATOR . $database;
                
                // Create the directory, if it does not exist
                if (!file_exists($this->path)) { starfish::obj('files')->smkdir($this->path); }
                
                // Create the safety index.html file
                if (!file_exists($this->path . DIRECTORY_SEPARATOR . 'index.html')) { starfish::obj('files')->w($this->path . DIRECTORY_SEPARATOR . 'index.html', ' '); }
                
                return true; 
        }
        
        /**
         * Function to disconnect from the database 
         */
        function disconnect()   { return true; }
        
        /**
         * Function to sanitize the input
         */
        function sanitize()     { return true; }
        
        /**
         * Function to escape the output
         */
        function escape($string)       
        { 
                return htmlspecialchars($string); 
        }
        
        /**
         * Function to execute a query
         * 
         * @param array $params Parameters of the request:
         *                      0 - the file/table
         *                      1 - the operation to be made
         *                      2 - the record / the function to use to filter results
         */
        function query($params)        
        { 
                $this->info = null;
                $this->fetch = 0;
                
                $file = $params[0];
                
                switch ($params[1])
                {
                        case 'c':
                                // Append to the file
                                $record = $this->sendRecord($params[2]);
                        
                                break;
                        case 'r':
                                // Read from the file
                                $this->selectRecords($file, );
                        
                                break;
                        case 'u':
                                // Update exising entry
                                $record = $this->sendRecord($params[2]);
                        
                                break;
                        case 'd':
                                // Delete existing entry
                                $record = $params[2];
                        
                                break;
                }
                
                return true; 
        }
        
        /**
         * Function to receive info about a query
         */
        function info()         { return $this->info; }
        
        /**
         * Function to fetch the results from a resource
         */
        function fetch()        { return true; }
        
        /**
         * Function to free a resource
         */
        function free()         { return true; }
        
        
        ##################
        # Internal functions
        ##################
        
        /**
         * Function get a record from the text file
         * 
         * @param string $serialized - Serialized retrieved from the text file
         * @return mixed The returned row
         */
        function getRecord($serialized)
        { 
                return @unserialize($serialized); 
        }
        
        /**
         * Function send a record to the text file
         * 
         * @param mixed Parameter to serialized
         * @return string Serialized string
         */
        function sendRecord($param)
        { 
                if (is_array($param)) { @ksort($param); }
                return @serialize($param); 
        }
        
        /**
         * Count the lines in the file/table
         * 
         * @param string $file The name of the file
         * @return number The number of lines counted
         */
        function countLines($file)
        {
                $linecount = 0;
                
                $handle = fopen($file, "r");
                while( !feof($handle) )
                {
                        $line = fgets($handle, 4096);
                        $linecount = $linecount + substr_count($line, PHP_EOL);
                }

                fclose($handle);
                
                return $linecount;
        }
        
        /**
         * Count the records in the file/table
         * 
         * @param string $file The name of the file
         * @param callable $callback The function to use to make sure the record is compatible
         * 
         * @return number The number of lines counted
         */
        function countRecords($file, $function)
        {
                // Go through the file to make the selection
                $count = 0;
                $filter = is_callable($callback) ? true : false;
                
                $handle = @fopen($file, "r");
                while(!@feof($handle))
                {              
                        // Get the line
                        $line = $this->getRecord( @fgets($handle) );
                        
                        // Store the result, if needed
                        if ($filter === true)
                        {
                                if (call_user_func($callback, $line) == true)
                                {
                                        $count++;
                                }
                        }
                        else
                        {
                                $count++;
                        }
                        
                        
                }
                
                @fclose($handle);
                
                return $count;
        }
        
        /**
         * Select the records in the file/table
         * 
         * @param string $file The name of the file
         * @param callable $callback The function to use to make sure the record is compatible
         * @param number $from The lower limit where to start the couting
         * @param number $to The limit of results to fetch
         * 
         * @return number The number of lines counted
         */
        function selectRecords($file, $callback, $from=0, $to=0)
        {
                // Go through the file to make the selection
                $count = 0;
                $filter = is_callable($callback) ? true : false;
                
                $handle = @fopen($file, "r");
                while(!@feof($handle))
                {              
                        // Get the line
                        $line = $this->getRecord( @fgets($handle) );
                        
                        // Store the result, if needed
                        if ($filter === true)
                        {
                                if (call_user_func($callback, $line) == true)
                                {
                                        if ($count >= $from)
                                        {
                                                $this->resource[] = $line;
                                        }
                                        
                                        if ( count($this->resource) > $to && $to !== 0)
                                        {
                                                break;
                                        }
                                        
                                        $count++;
                                }
                        }
                        else
                        {
                                if ($count >= $from)
                                {
                                        $this->resource[] = $line;
                                }

                                if ( count($this->resource) > $to && $to !== 0)
                                {
                                        break;
                                }


                                $count++;
                        }
                        
                        
                }
                
                $this->resource_count = $count;
                @fclose($handle);
                
                return true;
        }
}
?>