<?php
if (!class_exists('starfish')) { die(); }

/**
 * Extjs helper class
 *
 * @package starfish
 * @subpackage starfish.objects.extjs
 */
class extjs
{	
	/**
	 * Init the object
	 */
	public static function init()
	{
	}
}
?>